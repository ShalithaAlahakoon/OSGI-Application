package employeemanagemantpublisher;

public interface EmployeeInterface {
	public void insertEmployee();
	public void searchEmployee();
	public void getallemployee();
	public void deleteemployee();
	
}
