package resturantservicepublisher;

public interface ResturantServicePublish {
	public void insertReservation();
	public void getallReservations();
	public void getReservationsByCustName();
	public void deleteReservation();
	public void getPriorityNormal();	

}
