package resturantdb;

import java.sql.Connection;

public interface Database {

	public Connection getDatabaseConnection();
	
}
